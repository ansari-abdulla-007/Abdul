//create a class car and initialize color and model.
#include <iostream>
using namespace std;
class Car{
    public:
    string color;
    string model;
    Car(string c,string m){
        color=c;
        model=m;

        cout<<"Color: "<<color<<endl;
        cout<<"Model: "<<model<<endl;
    }
};
int main(){
    Car c1("Black","BMW M4");
    return 0;
}